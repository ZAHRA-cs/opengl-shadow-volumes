# ✅ SIMPLE CHECKLIST - ALL FILES READY

## 📥 DOWNLOAD THESE 10 FILES FROM OUTPUTS FOLDER:

### Main Files (3 files - put in project root):
1. ✅ **main_classmate.cpp** → rename to **main.cpp**
2. ✅ **Camera.h** (you already have from teacher)
3. ✅ **Shader.h** (you already have from teacher)

### Shader Files (7 files - put in res/shaders/):
4. ✅ **core.vs**
5. ✅ **ambient.fs**
6. ✅ **diffuse.fs**
7. ✅ **volume.vs**
8. ✅ **volume.fs**
9. ✅ **light.vs**
10. ✅ **light.fs**

---

## 📁 PUT FILES HERE:

```
YourProject/
├── main.cpp           ← File #1 (renamed)
├── Camera.h           ← File #2
├── Shader.h           ← File #3
└── res/
    └── shaders/
        ├── core.vs    ← File #4
        ├── ambient.fs ← File #5
        ├── diffuse.fs ← File #6
        ├── volume.vs  ← File #7
        ├── volume.fs  ← File #8
        ├── light.vs   ← File #9
        └── light.fs   ← File #10
```

---

## ▶️ RUN:

```bash
g++ main.cpp -o shadow -lGL -lGLEW -lglfw
./shadow
```

---

## ✅ DONE!

**All 10 files are in the outputs folder ready to download!**

Just organize them as shown above and compile! 🎉
