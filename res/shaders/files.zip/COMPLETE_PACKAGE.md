# COMPLETE PACKAGE - READY TO USE
## Everything You Need for Your Classmate's Project

---

## 📦 PACKAGE CONTENTS

### Main Files (Project Root):
1. **main.cpp** - Main program (rename from main_classmate.cpp)
2. **Camera.h** - Camera class (teacher's file - you have it)
3. **Shader.h** - Shader loader (teacher's file - you have it)

### Shader Files (res/shaders/ folder):
4. **core.vs** - Vertex shader for cube and ground
5. **ambient.fs** - Ambient lighting pass
6. **diffuse.fs** - Diffuse lighting pass
7. **volume.vs** - Shadow volume vertex shader
8. **volume.fs** - Shadow volume fragment shader
9. **light.vs** - Light cube vertex shader
10. **light.fs** - Light cube fragment shader

**TOTAL: 10 files (3 main + 7 shaders)**

---

## 🗂️ EXACT FOLDER STRUCTURE

```
YourProject/
│
├── main.cpp                    ← Rename main_classmate.cpp to this
├── Camera.h                    ← Teacher's file (you have it)
├── Shader.h                    ← Teacher's file (you have it)
│
└── res/
    └── shaders/
        ├── core.vs             ← Included
        ├── ambient.fs          ← Included
        ├── diffuse.fs          ← Included
        ├── volume.vs           ← Included
        ├── volume.fs           ← Included
        ├── light.vs            ← Included
        └── light.fs            ← Included
```

---

## 🚀 INSTALLATION STEPS

### Step 1: Create Folder Structure
```bash
mkdir -p YourProject/res/shaders
cd YourProject
```

### Step 2: Copy Main Files
Put these in the project root:
- `main.cpp` (the renamed main_classmate.cpp)
- `Camera.h` (you already have from teacher)
- `Shader.h` (you already have from teacher)

### Step 3: Copy Shader Files
Put these 7 files in `res/shaders/`:
- core.vs
- ambient.fs
- diffuse.fs
- volume.vs
- volume.fs
- light.vs
- light.fs

All shader files are provided below in this document!

### Step 4: Compile
```bash
# Linux/Mac
g++ main.cpp -o shadow -lGL -lGLEW -lglfw -lm

# Windows (MinGW)
g++ main.cpp -o shadow.exe -lopengl32 -lglew32 -lglfw3 -lgdi32
```

### Step 5: Run
```bash
./shadow          # Linux/Mac
shadow.exe        # Windows
```

---

## ✅ WHAT YOU'LL SEE

When running correctly:
- ✅ Window opens and stays open
- ✅ Large blue-gray ground plane (10×10)
- ✅ Colored cube sitting on the ground
- ✅ White light cube moving in oval pattern
- ✅ Shadow moving across ground

---

## 📄 ALL SHADER FILES (COPY-PASTE READY)

Copy each shader below into its respective file:

---

### FILE: core.vs
```glsl
#version 330 core
layout(location = 0) in vec3 position;
layout(location = 1) in vec3 color;
layout(location = 2) in vec3 normal;
out vec3 ourColor;
out vec3 Normal;
out vec3 PixelPos;
uniform mat4 transform;
uniform mat4 projection;
uniform mat4 view;
void main()
{
	gl_Position = projection * view * transform * vec4(position, 1.0f);
	ourColor = color;
	PixelPos = vec3(transform * vec4(position, 1.0f));
	Normal = mat3(transpose(inverse(transform))) * normal;
}
```

---

### FILE: ambient.fs
```glsl
#version 330 core

out vec4 FragColor;
in vec3 ourColor;
in vec3 Normal;
in vec3 PixelPos;

uniform vec3 LightPos;
uniform vec3 ViewPos;

void main()
{
    // Ambient light only
    float ambientStrength = 0.2;
    vec3 ambient = ambientStrength * ourColor;
    
    FragColor = vec4(ambient, 1.0);
}
```

---

### FILE: diffuse.fs
```glsl
#version 330 core

out vec4 FragColor;
in vec3 ourColor;
in vec3 Normal;
in vec3 PixelPos;

uniform vec3 LightPos;
uniform vec3 ViewPos;

void main()
{
    // Diffuse lighting calculation
    vec3 norm = normalize(Normal);
    vec3 lightDir = normalize(LightPos - PixelPos);
    float diff = max(dot(norm, lightDir), 0.0);
    vec3 diffuse = diff * vec3(1.0, 1.0, 1.0);
    
    // Specular component
    vec3 viewDir = normalize(ViewPos - PixelPos);
    vec3 halfAngle = normalize(lightDir + viewDir);
    float spec = pow(max(dot(norm, halfAngle), 0.0), 32);
    vec3 specular = spec * vec3(0.5, 0.5, 0.5);
    
    // Final color
    vec3 result = (diffuse + specular) * ourColor;
    FragColor = vec4(result, 1.0);
}
```

---

### FILE: volume.vs
```glsl
#version 330 core

layout (location = 0) in vec3 position;

uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * vec4(position, 1.0);
}
```

---

### FILE: volume.fs
```glsl
#version 330 core

out vec4 FragColor;

void main()
{
    FragColor = vec4(0.0, 0.0, 0.0, 1.0);
}
```

---

### FILE: light.vs
```glsl
#version 330 core
layout(location = 0) in vec3 position;
layout(location = 1) in vec3 color;
out vec3 ourColor;
uniform mat4 transform;
uniform mat4 projection;
uniform mat4 view;
void main()
{
	gl_Position = projection * view * transform * vec4(position, 1.0f);
	ourColor = color;
}
```

---

### FILE: light.fs
```glsl
#version 330 core
out vec4 FragColor;

void main()        
{
    FragColor = vec4(1.0f, 1.0f, 1.0f, 1.0f);
}
```

---

## 🔧 TROUBLESHOOTING

### Window closes immediately?
- ✅ Check all 7 shader files are in `res/shaders/`
- ✅ Verify file names are EXACTLY as shown (case-sensitive on Linux)
- ✅ Make sure you're running from project root (where `res/` folder is)

### Compilation errors?
```bash
# Install dependencies (Ubuntu/Debian)
sudo apt-get install libglew-dev libglfw3-dev

# Install dependencies (Fedora)
sudo dnf install glew-devel glfw-devel

# Install dependencies (Mac)
brew install glew glfw
```

### Black screen?
- Light might be too far - wait a few seconds for it to come into view
- Or adjust camera position in Camera.h

---

## 📋 CHECKLIST

Before running:
- [ ] main.cpp in project root
- [ ] Camera.h in project root
- [ ] Shader.h in project root
- [ ] res/shaders/ folder created
- [ ] All 7 shader files in res/shaders/
- [ ] Compiled successfully
- [ ] Running from correct directory

---

## 🎉 SUCCESS!

If everything works, you'll see a beautiful shadow volume demo with:
- Colorful cube on blue-gray ground
- Moving white light
- Dynamic shadow following the light

**All files ready - just copy and run!** 🚀
